import sagemaker
import pandas as pd
import numpy as np
import os
import sys
import boto3
from sagemaker.rl import RLEstimator, RLToolkit, RLFramework
# import matplotlib.pyplot as plt
import datetime
import random
import math

''' 

EXECUTE USING SOMETHING LIKE THIS: 
python run_rl_agent.py out train > run.log &
python run_rl_agent.py out_evaluate evaluate out > run_test.log &

'''

# ======================================
#
#    Read arguments from command line
#
# ======================================

# Local output filename
localout = sys.argv[1] 

# Optional second argument: train or evaluate
if len(sys.argv) == 3: mode = sys.argv[2]
    
# Optional third argument: name of checkpoint model folder name
if len(sys.argv) == 4: 
    mode = sys.argv[2]
    checkpointmodel = sys.argv[3]


    
# ====================================================
#
#   Loop over param if any, write config and run RL
#
# ====================================================

# Define session
sess = sagemaker.session.Session()
s3_bucket = sess.default_bucket()
s3_output_path = 's3://{}/'.format(s3_bucket)
job_name_prefix = 'rlnlp-litigation-review'
local_mode = False
role = sagemaker.get_execution_role()

# Create custom output folder
today = datetime.date.today()
print('Today is {}, let\'s get going!'.format(today.strftime('%b %d')))

# Train or evaluate
if mode == 'train': 
    entryfile = "train-coach.py"
elif mode == 'evaluate': 
    # Move checkpointed model (pre-trained RL agent) to S3 (required in SageMaker RL)
    checkpoint_dir = '{}/checkpoint'.format(checkpointmodel) 
    print("Starting from pre-trained agent checkpointed at {}".format(checkpoint_dir))
    checkpoint_path = "{}checkpoint/".format(s3_output_path)
    if not os.listdir(checkpoint_dir):
        raise FileNotFoundError("Checkpoint files not found under the path")
    os.system("aws s3 rm --recursive {}".format(checkpoint_path))    
    os.system("aws s3 cp --recursive {} {}".format(checkpoint_dir, checkpoint_path))
    print("S3 checkpoint file path: {}".format(checkpoint_path))
    entryfile = "evaluate-coach.py"          
else: 
    print('Mode (second argument) can only be train or evaluate')

# Write a config.py file that contain references for a 4-path synchronous (i.e. simultaneous) RL screening
if os.path.isfile('./src/config.py'): os.remove('./src/config.py')
out = open('./src/config.py', "a")
out.write('import os \n')
out.write('import datetime \n')
#out.write('import matplotlib.pyplot as plt \n') # need install python3-tk package on container
out.write('START_DATE = \'2012-08-13\' \n')
out.write('END_DATE = \'2017-08-11\' \n')
out.write('DATE_FORMAT = \'%Y-%m-%d\' \n')
out.write('EPS = 1e-8 \n')
out.write('CUR_DIR = os.path.dirname(__file__) \n')
out.write('DATA_DIR = os.path.join(CUR_DIR, \'data\') \n') 
out.write('OUT_DIR = \'/opt/ml/output/data\' \n')
out.close()

print('./src/config.py produced')

# Run RL
estimator = RLEstimator(source_dir='src',
                        entry_point=entryfile,
                        dependencies=["common/sagemaker_rl"],
                        toolkit=RLToolkit.COACH,
                        toolkit_version='0.11.0',
                        framework=RLFramework.MXNET,
                        role=role,
                        train_instance_count=1,
                        train_instance_type='ml.c5.9xlarge',
                        output_path=s3_output_path,
                        base_job_name=job_name_prefix,
                        hyperparameters = {"RLCOACH_PRESET" : "preset-litigation-review"},
                                        tags=[{'Key': 'User', 'Value': 'jcur01'}])

if mode == 'train': 
    # Fit from scratch:
    estimator.fit()  
elif mode == 'evaluate': 
    # Fit from pre-trained agent:
    estimator.fit({'checkpoint': checkpoint_path})
            
# Copy RL output from S3 to local output folder and uncompress files
job_name = estimator.latest_training_job.job_name
os.system('aws s3 cp {}{}/output/output.tar.gz ./{}/'.format(s3_output_path, job_name, localout))
os.system('cd ' + localout + '; tar xzvf output.tar.gz; rm output.tar.gz; cd ..')

print('DRL reviews complete. \n')
print('Output location on S3: {}{}/output/'.format(s3_output_path, job_name))


# =====================================
#
#   Send email and SMS notfications
#
# =====================================
    
# Send a notification job completed
sns = boto3.client('sns', region_name='us-east-2')
sns.publish(
            TopicArn = 'arn:aws:sns:us-east-2:524671764781:NLP-RL-Completed',
            Subject = 'RL Agent Audit - Job Complete',
            Message = 'Ready to analyze. S3 output folder: {}{}/output and locafolder: ./{}'.format(s3_output_path, job_name, localout)    
           )
