import os 
import datetime 
START_DATE = '2012-08-13' 
END_DATE = '2017-08-11' 
DATE_FORMAT = '%Y-%m-%d' 
EPS = 1e-8 
CUR_DIR = os.path.dirname(__file__) 
DATA_DIR = os.path.join(CUR_DIR, 'data') 
OUT_DIR = '/opt/ml/output/data' 
