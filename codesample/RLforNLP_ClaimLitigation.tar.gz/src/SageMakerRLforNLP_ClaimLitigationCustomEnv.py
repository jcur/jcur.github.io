
""" =============================================================

       Algorithm for Financial Claim Litigation Review with Deep
         Reinforcement Learning & Natural Language Processing
       
               Amazon Machine Learning Solutions Lab
                    AWS Professional Services

                    Date Created: 4/22/2019 
                    by: Jeremy D. Curuksu, PhD
                    
                    Latest Update: 7/15/2019                    
                    by: Jeremy D. Curuksu
                    
============================================================= """


# ========================
#                               
#      Modules Import        
#                                                             
# ========================

import gym
import gym.spaces
import numpy as np
import pandas as pd
import math
import random
import keras
from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense
from keras.optimizers import Adam
from config import *
from collections import deque
from pprint import pprint
import csv
import boto3
import json
import time
import os


# ========================
#                               
#        Main Class        
#                                                             
# ========================
    
class ReviewEnv(gym.Env):

    def __init__(self,
                 corpus = 'test1000',             # Prefix of filename containing items to review (text or pre-embedded format)
                 mode = 'text',                   # Review can be on original text or pre-coded embedding vectors 
                 edim = 100,                      # Dimension of embedding space for an item
                 econ = 22,                       # Dimension of context data (number of columns) for an item
                 ewind = 11,                      # Size of rolling window across items (e.g. 10 + 1)
                 encoder = 'encoder-v2',          # Endpoint to pre-trained NLP encoder
                 supervisor = 'supervisor-v2'     # Endpoint to pre-trained NLP classifier 
                 ):

        print('Agent will review {} in {} mode'.format(corpus,mode))        
        
        # Define class attributes
        self.corpus = '{}/{}'.format(DATA_DIR,corpus)
        self.odir = OUT_DIR 
        self.mode = mode
        self.edim = edim 
        self.econ = econ 
        self.ewind = ewind
        self.encoder = encoder
        self.supervisor = supervisor 
        
        # Action space size
        # self.action_space = gym.spaces.Discrete(2) 
        self.action_space = gym.spaces.Box(0, 1, shape=(1,), dtype=np.float32) 
        
        # Observation space size
        #self.observation_space = gym.spaces.Box(-1,1,shape=(11,self.edim,1), dtype=np.float32)   
        obs_dim = self.ewind * (self.edim + self.econ)
        self.observation_space = gym.spaces.Box(-1,1,shape=(obs_dim,), dtype=np.float32)  

        # Store line items (needed for nlp supervisor) and group-level (e.g. invoice-level) labels/indices
        self.lineitems = getItems(self.corpus) 
        self.grouplabels = getInvoiceLabels(self.corpus) 
        self.groupindices = getInvoiceIndices(self.corpus) 

        # Define set of states in embedding space, i.e. encode text with pre-trained nlp model (or read vectors if available)
        self.vecspace = getObservation(self.corpus, self.mode, self.encoder, self.edim, self.econ, self.odir) 
        self.steps = len(self.vecspace) - 1
        print("Number of steps:", self.steps)

        # Instantiate reward counters and tracking tables from previous episode for analyzing performance 
        self.total_rewards = 0                            # Sum of item rewards
        self.total_grouprewards = 0                       # Sum of group rewards 

        # Initialize step index and episode index
        #self.t = 0 
        self.e = 0
        
    def reset(self):
        
        # Reset state and infos table
        self.t = 0
        self.state = getState(self.vecspace, self.t, self.ewind)
        self.infos = []
        
        # Increment episode index
        self.e += 1

        # Reset accumulated reward variables 
        self.total_rewards = 0                             # Sum of item rewards per episode
        self.total_grouprewards = 0                        # Sum of group rewards per episode
        self.total_items = 0                               # Number items in current group
        self.total_action1 = 0                             # Number actions 1 taken by agent in current group
        self.total_label1 = 0                              # Number labels 1 for training in current group
                              
        return np.array(self.state[0])       
        

    def step(self, action):

        '''      
        Reinforcement Learning Components:     
           - GOAL:         Optimal policy for finding spread/related items in invoices
           - OBSERVATIONS: Items in invoices
           - STATES:       Embedding vectors of items in invoices
           - ACTIONS:      0 (compliant) or 1 (non-compliant)
           - STATE REWARD: Difference between agent action and probability predicted by a pre-trained NLP classifier
           - FINAL REWARD: Normalized difference between total number of non-compliant items predicted by agent vs. reviewer
        
        In a Nutchell, and plain english...
           The agent learns optimal policies to assign compliance based on patterns within and between items.
           A state is an item observed in a financial invoice and encoded via NLP. The RL agent reads each 
           item one by one and takes an action for each item. For each action taken, the environment emits 
           a reward by comparing the agent action with a probability predicted by a pre-trained NLP classifier.
           At the end of an invoice, the environment emits a final reward by comparing the sum of all actions 
           taken by the agent with the sum of all decisions previously made by a human reviewer 
        '''
        
        # Numerical/probabilistic action space: rescale in discrete space
        action_p = np.clip(action[0], 0, 1)
        action = np.round(action_p).astype(int)   # round up/down to an integer value
        assert ((action >= 0) * (action <= 1)).all(), 'all action values should be between 0 and 1. Not %s' % action
        
        # Categorical action space: clip to custom categories
        # actions = [0,1]
        # move = actions[action]
        # assert self.action_space.contains(action), "%r (%s) invalid"%(action, type(action))

        # Define indices locally to simplify notations
        t = self.t
        steps = self.steps
              
        # Get original line item at time t for the supervisor to provide a feedback
        lineitem = getItem(self.lineitems, t)
                
        # Compute probability feedback from supervised learning
        p = getSupervision(lineitem, self.supervisor)    
         
        # Get label from human reviewer feedback (group-level feedback)                       
        label1 = int(getItem(self.grouplabels, t))        

        # Define shaping reward based on supervisor feedback (or based on ground truth)
        # reward = - (action - p)**2 
        # reward = - abs(action_p - label1)
        '''
        # Latest version before moving to categorical reward function
        reward = - (action_p - label1)**2  
        boost = 100 # Option to set up boosting for instant reward
        if label1 == 0: 
            reward = boost * reward         
        '''
        
        # Define reward function with empirical discrete categories
        if label1 == 1:
            if action_p > 0.5: 
                reward = 100
            elif action_p > 0.2:
                reward = 50     
            else:
                reward = 0
        else:
            if action_p < 0.2: 
                reward = 30
            elif action_p < 0.5:
                reward = 20     
            else:
                reward =  0           
        
        # Accumulate rewards, items, actions and labels
        self.total_rewards += reward
        self.total_items   += 1
        self.total_action1 += action  
        self.total_label1  += label1                   
                
        # Define reward at end of group             
        if getItem(self.groupindices, t) != getItem(self.groupindices, t + 1): 
                    
            # Define a group-level reward (scaled for group size)
            groupreward = - (self.total_action1 - self.total_label1)**2 / self.total_items
            #boost = 1 # Option to set up boosting for final reward
            #reward = boost * groupreward 

            # Store sum of group rewards
            self.total_grouprewards += groupreward
                
            # Reset counter for items, actions and labels
            self.total_action1 = 0
            self.total_label1  = 0
            self.total_items   = 0
                    
        # Set flag for experience replay to learn using end-of-group-level reward 
        # Define custom episodes (instead of invoices) to increase computational speed
        #if (t % 250 == 0): 
        #        done = True
        #else:
        #        done = False

                              
        # Print info
        info = {'Step': self.t}    
        info['Action'] = action 
        info['Action_p'] = action_p
        info['Truth'] = label1 
        info['p'] = p 
        info['TotalActions'] = self.total_action1 
        info['TotalLabels'] = self.total_label1   
        info['Reward'] = reward
        info['TotalReward'] = self.total_rewards 
        info['TotalGroupReward'] = self.total_grouprewards
        
        self.infos.append(info)
       
        # ******** DEBUGGING **********************************************
        #print('Action: {}'.format(action))
        #print('Action_p: {}'.format(action_p))
        #print('Truth: {}'.format(label1))
        #print('p (from super): {}'.format(p))
        #print('Reward: {:.4f}'.format(reward))
        #print('Total Reward: {:.4f}'.format(self.total_rewards))
        #print('Total Group Reward: {:.4f}'.format(self.total_grouprewards))
        # ****************************************************************

        # At EOF set flag for experience replay and reset step index. If not EOF, increment to next step
        if self.t == self.steps - 1:           
            done = True 
            #self.t = 0   
            #eof = 1 # to define custom episodes
        else:          
            done = False 
            #self.t += 1   
            #eof = 0 # to define custom episodes
          
        self.t += 1  
        
        # Return reward, next state and done status to store current experience in memory
        self.state = getState(self.vecspace, self.t, self.ewind)
        
        # At end of episode, print final rewards in this episode and save logs to file 
        if done: 
            keys = self.infos[0].keys()
            ofile = '{}/rlnlp_results.csv'.format(self.odir)
            with open(ofile, 'a', newline='') as f:
                dict_writer = csv.DictWriter(f, keys)
                # Write header only at EOF to make it easier to triage/render entire dataset 
                dict_writer.writeheader() # Condition on (if eof == 1:) to define custom episodes
                dict_writer.writerows(self.infos) 
        
                
        return np.array(self.state[0]), reward, done, info



#================================
#                               
#       Helper Functions        
#                                                             
#================================
                                 
# Function to translate set of items into set of embedding vectors
def getObservation(datasource, datatype, endpoint, edim, econ, odir):

        ''' 
        Call endpoint of pre-trained Word2vec encoder
        7 parameters:
            1. Entire set of items (= the entire environment if not too large)
            2. Type of data, either text or pre-processed vector space
            3. Endpoint pointing to pre-trained Word2vec encoder
            4. Dimension of embedding space
            5. Entire set of context data 
            6. Dimension of context data feature space (number of columns after one-hot encoding)
            7. Output path
        '''
        
        if datatype == 'text':
        
            # Read raw text data and prepare for NLP processing
            print('Creating embedding space.')
            data = open('{}_sl_label_noidentical'.format(datasource), "r").readlines()
            data = [x.strip() for x in data]
            
            # Read associated context data file 
            context = np.loadtxt('{}_sl_label_context'.format(datasource), delimiter=',')

            # Make sure label is not included in items
            items = []
            for item in data:
                item = item.replace('__label__0','')
                item = item.replace('__label__1','')
                items.append(item)

            # For each item, run pre-trained Word2vec encoder as many times as  
            # there are words in item then average all word vectors across item 
            ntotal = len(items)
            print("Number of line items: ",ntotal)
            vec = np.zeros(shape=(ntotal, edim + econ))
            for n in range(ntotal):
                itemwords = items[n].split(' ')
                i = 0
                v = np.zeros(edim)
                for word in itemwords:
                    if word:
                        payload = {"instances": [word]}
                        sagemaker = boto3.client('sagemaker-runtime', region_name='us-east-1')
                        result = sagemaker.invoke_endpoint(EndpointName=endpoint,Body=json.dumps(payload))
                        result = result['Body'].read()
                        result = np.array(json.loads(result.decode('utf-8'))).ravel()                      
                        wordvec = result[0]['vector']   
                        # word = result[0]['word']
                        v = v + np.array(wordvec)
                        i += 1
                v = v / i
                vec[n,:] = np.concatenate((v, context[n]), axis=0)
                #print('***** DEBUGGING ***** vec at step {}: {}'.format(n, vec[n,:]))
                if not((n+1)%1000): print('Processed',n+1,'line items')

            # Save observations in embedding space to binary file (.npy)
            np.save('{}_vecspace.npy'.format(datasource), vec) 
            print("Embedding space created.")

        else:
            
            # Read embedding vectors directly
            vec = np.load('{}_vecspace.npy'.format(datasource))
            # vec = np.load('{}_sl_label_noidentical.npy'.format(datasource)) 
            
        return vec
    
    
# Function to predict class probability for an item using a pre-trained NLP classifier
def getSupervision(lineitem, endpoint):
                              
        ''' 
        Call endpoint of pre-trained Word2vec classifier
        2 parameters:
            1. An individual item
            2. Endpoint pointing to pre-trained Word2vec classifier
        '''
                                                         
        # Run pre-trained BlazzingText classifier on item
        payload = {"instances": [lineitem]}
        sagemaker = boto3.client('sagemaker-runtime', region_name='us-east-1')
        result = sagemaker.invoke_endpoint(EndpointName=endpoint,Body=json.dumps(payload))
        result = result['Body'].read()
        result = np.array(json.loads(result.decode('utf-8'))).ravel()
        p = result[0]['prob'][0]
        label = int(result[0]['label'][0].strip('__label__'))
        p = np.clip(p, a_min = 0, a_max = 1) 
        if label == 0: p = 1 - p # BlazzingText returns non-holonomic probabilities (p for returned label; no reference label)

        return p    


# Function to clean items and store them in an array:
def getItems(datasource):
    
        # Read text data and strip empty values 
        data = open('{}_sl_label_noidentical'.format(datasource), "r").readlines()
        data = [x.strip() for x in data]
        
        # Make sure label is not included in the items
        items = []
        for item in data:
            item = item.replace('__label__0','')
            item = item.replace('__label__1','')
            items.append(item)
                
        return items
    

# Function to read group-level (e.g. invoice-level) index of item
def getInvoiceIndices(datasource):
        
        '''
        WARNING: Assumes data file has same name but with extension '_invoices' and contains:
                 Column 1: Item label
                 Column 2: Item
                 Column 3: Item group-level index
        '''
        
        # Read raw text data 
        data = open('{}_rl_labels_noidentical'.format(datasource), "r").readlines()
        
        # Extract the group-level index located at the end of the line item
        indices = []
        for item in data:
            item = item.strip() # Needed if counting from the end
            item = item.split() # Needed to list words not characters
            indices.append(item[-1])
                           
        return indices


# Function to read group-level (e.g. invoice-level) label of item
def getInvoiceLabels(datasource):
        
        '''
        WARNING: Assumes data file has same name but with extension '_invoices' and contains:
                 Column 1: Item label
                 Column 2: Item
                 Column 3: Item group-level index
        '''
        
        # Read raw text data 
        data = open('{}_rl_labels_noidentical'.format(datasource), "r").readlines()
        
        # Extract the group-level label located at the end of the line item
        labels = []
        for item in data:
            item = item.replace('__label__0','0')
            item = item.replace('__label__1','1')
            item = item.strip() # Needed if counting from the end
            item = item.split() # Needed to list words not characters
            labels.append(item[0])
                           
        return labels
                           
                           
# Function to select item located at index t in list of items:
def getItem(items, t):                
        return items[t]

# Function to select vector located at index t in array of vectors:
def getState(vectors, t, ewind):
    
        ''' CODE FOR WINDOW OF "ewind" ITEMS WITH "ewind - 1" PRIOR STEPS + t AS LAST ITEM'''
        s = vectors.shape
        #halfwind = int((ewind - 1) / 2)
        if t < ewind - 1:
            # Fill vec for first index then loop over other indices
            i = t; vec = vectors[i,:] 
            for i in range(t + 1, t + ewind):
                vec = np.concatenate((vec, vectors[i,:]), axis=None)
                #vec  = vec + vectors[i,:] 
        #elif t < s[0] - 5:
        #    # Fill vec for first index then loop over other indices
        #    i = t - halfwind; vec = vectors[i,:]
        #    for i in range(t - halfwind + 1, t + halfwind + 1):
        #        vec = np.concatenate((vec, vectors[i,:]), axis=None)
        #        #vec  = vec + vectors[i,:]
        else:
            # Fill vec for first index then loop over other indices
            i = t - ewind + 1; vec = vectors[i,:]
            for i in range(t - ewind + 2, t + 1):
                vec = np.concatenate((vec, vectors[i,:]), axis=None)
                #vec  = vec + vectors[i,:]
        #print('*********** Debugging, Tensor shape: ',vec.shape)
        #print(vec)
        return np.array([vec])    
    
        ''' CODE FOR WINDOW OF 11 ITEMS WITH t IN THE MIDDLE    
        s = vectors.shape
        halfwind = int((ewind - 1) / 2)
        if t < 5:
            # Fill vec for first index then loop over other indices
            i = t; vec = vectors[i,:] 
            for i in range(t + 1, t + ewind):
                vec = np.concatenate((vec, vectors[i,:]), axis=None)
                #vec  = vec + vectors[i,:] 
        elif t < s[0] - 5:
            # Fill vec for first index then loop over other indices
            i = t - halfwind; vec = vectors[i,:]
            for i in range(t - halfwind + 1, t + halfwind + 1):
                vec = np.concatenate((vec, vectors[i,:]), axis=None)
                #vec  = vec + vectors[i,:]
        else:
            # Fill vec for first index then loop over other indices
            i = t - ewind + 1; vec = vectors[i,:]
            for i in range(t - ewind + 2, t + 1):
                vec = np.concatenate((vec, vectors[i,:]), axis=None)
                #vec  = vec + vectors[i,:]
        #print('*********** Debugging, Tensor shape: ',vec.shape)
        #print(vec)
        return np.array([vec])
        '''

'''   
# Attempt to create 3D tensor - Gym dimension error to fix: (3 vs. 4), or following error:
# "!!! Failed to instantiate Gym environment class (...) with observation space type None"
# See: https://nervanasystems.github.io/coach/_modules/rl_coach/environments/gym_environment.html
def getState(vectors, t):
        tensor = np.ones((11,100,1)) # **** STATIC PARAM TO REPLACE BY VARIABLE NAMES
        s = vectors.shape
        if t < 5:
            tensor[:,:,0]  = vectors[t:t+11,:] # tensor = np.array([vectors[t:t+11,:]])
        elif t < s[0] - 5:
            tensor[:,:,0] = vectors[t-5:t+6,:] # tensor = np.array([vectors[t-5:t+6,:]])
        else:
            tensor[:,:,0] = vectors[t-10:t+1,:] # tensor = np.array([vectors[t-10:t+1,:]])
        print('*********** Debugging, Tensor shape: ',tensor.shape)
        print(tensor)
        return tensor
'''

# Function to render a float:
def formatFloat(r):
        return "{0:.2f}".format(r)
    
# Function to transform action into human understandable label
def formatLabel(a):    
        if a == 0:
            label = 'Compliant'
        elif a == 1:
            label = 'Non-compliant'
        else:
            label = 'Uncertain (review definition of actionlabel function)'
            
        return label
